"use strict";exports.id=5878,exports.ids=[5878],exports.modules={55878:(t,e,n)=>{n.d(e,{c:()=>useContract});var i=n(9885),o=n(83994),a=n(9941),r=n(71113),s=n(15485),l=n(5413),c=n(79614);async function authHeader(){let{data:t}=await l.O.auth.getSession(),e=t.session?.access_token;return{...(0,c.m9)(),...e?{authorization:`Bearer ${e}`}:{}}}var u=n(70647),d=n(43165);function requireFtAssetName(t){let e=function(t){let e=t.split("."),n=e.length>1?e[e.length-1]:t;if(r.Rg[n])return r.Rg[n];let i=n.match(/^([a-z0-9]+)-token-\d+$/);return i?`${i[1]}-ft`:null}(t);if(!e)throw Error(`[SSE] Could not derive the fungible-token asset name for "${t}". Add it to FT_ASSET_NAMES, or ensure the contract name follows the '<symbol>-token-<timestamp>' convention. Refusing to send a transaction with an unchecked asset movement.`);return e}function useContract(){let t=(0,i.useCallback)(t=>{let[e,...n]=t.split(".");return e&&0!==n.length?(0,o.contractPrincipalCV)(e,n.join(".")):(0,o.principalCV)(t)},[]),{executeContractCall:e,requestContractDeploy:n}=function(){let t=(0,i.useCallback)(async(t,e,n)=>{let i={"content-type":"application/json",...await authHeader()},a=await fetch("/api/custodial/execute",{method:"POST",headers:i,body:JSON.stringify({contract:t,function:e,argsHex:n.map(o.cvToHex)})}),r=await a.json().catch(()=>({}));if(!a.ok)throw Error(r.error||`execute failed (HTTP ${a.status})`);return r.txid},[]),e=(0,i.useCallback)(async(t,e,n)=>{let i={"content-type":"application/json",...await authHeader()},a=await fetch("/api/custodial/requests",{method:"POST",headers:i,body:JSON.stringify({contract:t,function:e,argsHex:n.map(o.cvToHex)})});if(!a.ok)throw Error(`request failed: ${a.status}`);return(await a.json()).request},[]),n=(0,i.useCallback)(async(t,e)=>{let n={"content-type":"application/json",...await authHeader()},i=await fetch("/api/custodial/requests",{method:"POST",headers:n,body:JSON.stringify({contract:"__deploy__",function:"__deploy__",argsHex:[t,e]})});if(!i.ok)throw Error(`request failed: ${i.status}`);return(await i.json()).request},[]);return{executeContractCall:t,requestContractCall:e,requestContractDeploy:n}}(),{custodialAddress:l}=(0,u.a)(),c=(0,i.useCallback)(async t=>{let{contractName:n,functionName:i,functionArgs:o,onSuccess:l,onError:c}=t,u=a.toast.loading("Submitting transaction…");try{let t=await e(n,i,o);(0,s.$p)(),(0,d.cZ)(t,`${n}.${i}`),a.toast.success("Transaction submitted",{id:u,description:`Broadcast on-chain \xb7 ${t.slice(0,10)}…`,duration:15e3,action:{label:"View on explorer",onClick:()=>window.open((0,r.QG)(t),"_blank","noopener,noreferrer")}}),l?.(t)}catch(t){a.toast.error("Transaction failed",{id:u,description:t.message}),c?.(t)}},[e]),p=(0,i.useCallback)(()=>l,[l]),f=(0,i.useCallback)((t,e,n)=>c({contractName:r.qE.MULTI_ASSET_VAULT_ENGINE,functionName:"open-vault-for-stablecoin",functionArgs:[(0,o.uintCV)(t)],postConditions:[],postConditionMode:"deny",onSuccess:e,onError:n}),[c]),C=(0,i.useCallback)((e,n,i,a,s)=>{let l;let u=p();if(u)try{let t=requireFtAssetName(n);l=[o.Pc.principal(u).willSendLte(i).ft(n,t)]}catch(t){return s?.(t),Promise.reject(t)}return c({contractName:r.qE.MULTI_ASSET_VAULT_ENGINE,functionName:"deposit-collateral-for-stablecoin",functionArgs:[(0,o.uintCV)(e),t(n),t(n),(0,o.uintCV)(i)],postConditions:l,postConditionMode:"deny",onSuccess:a,onError:s})},[c,t,p]),m=(0,i.useCallback)((e,n,i,a,s,l,u)=>{if(r.GG&&!s){let t=Error(`[SSE] mint-against-asset-for-stablecoin requires an oracleContract on v8 (asset=${n}). Resolve it via getOraclePrincipalForAsset() before calling.`);return u?.(t),Promise.reject(t)}let d=r.GG&&s?[t(s)]:[];return c({contractName:r.qE.MULTI_ASSET_VAULT_ENGINE,functionName:"mint-against-asset-for-stablecoin",functionArgs:[(0,o.uintCV)(e),(0,o.principalCV)(n),t(i),...d,(0,o.uintCV)(a)],postConditions:[],postConditionMode:"deny",onSuccess:l,onError:u})},[c,t]),E=(0,i.useCallback)((e,n,i,a,s,l)=>{let u;let d=p();if(d)try{let t=requireFtAssetName(i);u=[o.Pc.principal(d).willSendLte(a).ft(i,t)]}catch(t){return l?.(t),Promise.reject(t)}return c({contractName:r.qE.MULTI_ASSET_VAULT_ENGINE,functionName:"repay-against-asset-for-stablecoin",functionArgs:[(0,o.uintCV)(e),(0,o.principalCV)(n),t(i),(0,o.uintCV)(a)],postConditions:u,postConditionMode:"deny",onSuccess:s,onError:l})},[c,t,p]),N=(0,i.useCallback)((e,n,i,a,s,l)=>{let u;if(r.GG&&!a){let t=Error(`[SSE] withdraw-collateral-for-stablecoin requires an oracleContract on v8 (asset=${n}).`);return l?.(t),Promise.reject(t)}let d=(0,r.jU)(r.qE.MULTI_ASSET_VAULT_ENGINE);try{let t=requireFtAssetName(n);u=[o.Pc.principal(d).willSendLte(i).ft(n,t)]}catch(t){return l?.(t),Promise.reject(t)}let p=r.GG&&a?[t(a)]:[];return c({contractName:r.qE.MULTI_ASSET_VAULT_ENGINE,functionName:"withdraw-collateral-for-stablecoin",functionArgs:[(0,o.uintCV)(e),t(n),t(n),...p,(0,o.uintCV)(i)],postConditions:u,postConditionMode:"deny",onSuccess:s,onError:l})},[c,t]),b=(0,i.useCallback)((t,e,n,i,a,s)=>{let l=a||p(),u=l&&s&&s>0?[o.Pc.principal(l).willSendLte(s).ustx()]:[];return c({contractName:r.qE.STABLECOIN_FACTORY,functionName:"register-stablecoin",functionArgs:[(0,o.stringAsciiCV)(t),(0,o.stringAsciiCV)(e)],postConditionMode:"deny",postConditions:u,onSuccess:n,onError:i})},[c,p]),g=(0,i.useCallback)(async(t,e,i,o)=>{let l=function(t){let e=Math.floor(Date.now()/1e3);return`${t.toLowerCase()}-token-${e}`}(e),c=function(t,e){let n=r.qE.DEPLOYER,i=`${n}.${r.qE.MULTI_ASSET_VAULT_ENGINE}`,o=`${e.toLowerCase()}-ft`;return`
;; Auto-generated SIP-010 token for "${t}" (${e})
;; Deployed via SSE Stablecoin Factory
;; Uses native define-fungible-token for post-condition support

(impl-trait 'SP3FBR2AGK5H9QBDH3EEN6DF8EK8JY7RX8QJ5SVTE.sip-010-trait-ft-standard.sip-010-trait)
(impl-trait '${n}.stablecoin-engine-token-trait.stablecoin-engine-token-trait)

(define-constant CONTRACT-OWNER tx-sender)

(define-constant ERR_UNAUTHORIZED u401)

(define-constant TOKEN-NAME "${t}")
(define-constant TOKEN-SYMBOL "${e}")
(define-constant TOKEN-DECIMALS u6)

(define-fungible-token ${o})

;; Pre-authorise the SSE vault engine so vaults work immediately
(define-data-var vault-engine (optional principal) (some '${i}))

(define-read-only (is-vault-engine (caller principal))
  (match (var-get vault-engine)
    ve (is-eq ve caller)
    false
  )
)

(define-public (set-vault-engine (new principal))
  (begin
    (asserts! (is-eq tx-sender CONTRACT-OWNER) (err ERR_UNAUTHORIZED))
    (var-set vault-engine (some new))
    (ok true)
  )
)

(define-public (transfer (amount uint) (sender principal) (recipient principal) (memo (optional (buff 34))))
  (begin
    (asserts! (is-eq tx-sender sender) (err ERR_UNAUTHORIZED))
    (try! (ft-transfer? ${o} amount sender recipient))
    (match memo to-print (print to-print) 0x)
    (ok true)
  )
)

(define-public (mint (amount uint) (recipient principal))
  (begin
    (asserts! (is-vault-engine contract-caller) (err ERR_UNAUTHORIZED))
    (ft-mint? ${o} amount recipient)
  )
)

(define-public (burn (amount uint) (owner principal))
  (begin
    (asserts! (is-vault-engine contract-caller) (err ERR_UNAUTHORIZED))
    (ft-burn? ${o} amount owner)
  )
)

(define-read-only (get-name)
  (ok TOKEN-NAME)
)

(define-read-only (get-symbol)
  (ok TOKEN-SYMBOL)
)

(define-read-only (get-decimals)
  (ok TOKEN-DECIMALS)
)

(define-read-only (get-balance (who principal))
  (ok (ft-get-balance ${o} who))
)

(define-read-only (get-total-supply)
  (ok (ft-get-supply ${o}))
)

(define-read-only (get-token-uri)
  (ok none)
)
`.trim()}(t,e),u=a.toast.loading("Queueing deployment…");try{let t=await n(l,c);(0,s.$p)(),a.toast.info("Deployment needs approval",{id:u,description:"An approver must sign off before this token deploys.",action:{label:"View pending requests",onClick:()=>{window.location.href="/custodial/approvals"}}}),i?.(t.id,l)}catch(t){a.toast.error("Could not queue deployment",{id:u,description:t.message}),o?.(t)}},[n]),A=(0,i.useCallback)((e,n,i,a)=>c({contractName:r.qE.STABLECOIN_FACTORY,functionName:"set-token-contract",functionArgs:[(0,o.uintCV)(e),t(n)],postConditions:[],postConditionMode:"deny",onSuccess:i,onError:a}),[c,t]),T=(0,i.useCallback)((e,n,i,a,s)=>c({contractName:r.qE.COLLATERAL_REGISTRY,functionName:"configure-collateral-for-stablecoin",functionArgs:[(0,o.uintCV)(e),t(n),(0,o.uintCV)(i.minCollateralRatio),(0,o.uintCV)(i.liquidationRatio),(0,o.uintCV)(i.liquidationPenalty),(0,o.uintCV)(i.stabilityFee),(0,o.uintCV)(i.debtCeiling),(0,o.uintCV)(i.debtFloor)],postConditions:[],postConditionMode:"deny",onSuccess:a,onError:s}),[c,t]),y=(0,i.useCallback)((e,n,i,a,s)=>c({contractName:r.qE.COLLATERAL_REGISTRY,functionName:"update-collateral-for-stablecoin",functionArgs:[(0,o.uintCV)(e),t(n),(0,o.uintCV)(i.minCollateralRatio),(0,o.uintCV)(i.liquidationRatio),(0,o.uintCV)(i.liquidationPenalty),(0,o.uintCV)(i.stabilityFee),(0,o.uintCV)(i.debtCeiling),(0,o.uintCV)(i.debtFloor)],postConditions:[],postConditionMode:"deny",onSuccess:a,onError:s}),[c,t]),S=(0,i.useCallback)((e,n,i,a)=>c({contractName:r.qE.COLLATERAL_REGISTRY,functionName:"disable-collateral-for-stablecoin",functionArgs:[(0,o.uintCV)(e),t(n)],postConditions:[],postConditionMode:"deny",onSuccess:i,onError:a}),[c,t]),k=(0,i.useCallback)((e,n,i,a)=>c({contractName:r.qE.COLLATERAL_REGISTRY,functionName:"enable-collateral-for-stablecoin",functionArgs:[(0,o.uintCV)(e),t(n)],postConditions:[],postConditionMode:"deny",onSuccess:i,onError:a}),[c,t]),V=(0,i.useCallback)((e,n,i,a,s)=>{let l;let u=p();if(u)try{let t=requireFtAssetName(n);l=[o.Pc.principal(u).willSendLte(i).ft(n,t)]}catch(t){return s?.(t),Promise.reject(t)}return c({contractName:r.qE.STABILITY_POOL,functionName:"deposit",functionArgs:[(0,o.uintCV)(e),t(n),(0,o.uintCV)(i)],postConditions:l,postConditionMode:"deny",onSuccess:a,onError:s})},[c,t,p]),L=(0,i.useCallback)((e,n,i,a,s)=>{let l;let u=(0,r.jU)(r.qE.STABILITY_POOL);try{let t=requireFtAssetName(n);l=[o.Pc.principal(u).willSendLte(i).ft(n,t)]}catch(t){return s?.(t),Promise.reject(t)}return c({contractName:r.qE.STABILITY_POOL,functionName:"withdraw",functionArgs:[(0,o.uintCV)(e),t(n),(0,o.uintCV)(i)],postConditions:l,postConditionMode:"deny",onSuccess:a,onError:s})},[c,t]),_=(0,i.useCallback)((t,e,n,i)=>c({contractName:r.qE.STABILITY_POOL,functionName:"set-liquidation-reward-pct",functionArgs:[(0,o.uintCV)(t),(0,o.uintCV)(e)],postConditions:[],postConditionMode:"deny",onSuccess:n,onError:i}),[c]),w=(0,i.useCallback)((e,n,i,a)=>c({contractName:r.qE.STABILITY_POOL,functionName:"claim-collateral-reward",functionArgs:[(0,o.uintCV)(e),t(n),t(n)],postConditions:[],postConditionMode:"deny",onSuccess:i,onError:a}),[c,t]),h=(0,i.useCallback)((t,e,n,i,a)=>c({contractName:t,functionName:"faucet-mint",functionArgs:[(0,o.uintCV)(e),(0,o.standardPrincipalCV)(n)],postConditionMode:"allow",postConditions:[],onSuccess:i,onError:a}),[c]),q=(0,i.useCallback)((e,n,i,a,s,l)=>c({contractName:r.qE.LIQUIDATION_ENGINE,functionName:"liquidate",functionArgs:[(0,o.principalCV)(e),(0,o.uintCV)(n),t(i),t(i),t(a)],postConditions:[],postConditionMode:"deny",onSuccess:s,onError:l}),[c,t]);return{callContract:c,openVaultForStablecoin:f,depositCollateralForStablecoin:C,mintAgainstAssetForStablecoin:m,repayAgainstAssetForStablecoin:E,withdrawCollateralForStablecoin:N,registerStablecoin:b,deployTokenContract:g,setTokenContract:A,configureCollateralForStablecoin:T,updateCollateralForStablecoin:y,disableCollateralForStablecoin:S,enableCollateralForStablecoin:k,depositToPool:V,withdrawFromPool:L,setLiquidationRewardPct:_,claimCollateralReward:w,liquidate:q,faucetMint:h}}}};