(()=>{var e={};e.id=3355,e.ids=[3355],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},6113:e=>{"use strict";e.exports=require("crypto")},71017:e=>{"use strict";e.exports=require("path")},57310:e=>{"use strict";e.exports=require("url")},89402:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>u,originalPathname:()=>m,pages:()=>d,routeModule:()=>x,tree:()=>c});var a=s(67096),r=s(16132),n=s(37284),l=s.n(n),i=s(32564),o={};for(let e in i)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>i[e]);s.d(t,o);let c=["",{children:["my-stablecoins",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,48860)),"/Users/yehiatarek/Documents/projects/Stacks/Stacks Stablecoin Engine (SSE)/frontend/src/app/my-stablecoins/page.tsx"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,73881))).default(e),async e=>(await Promise.resolve().then(s.bind(s,97026))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(s.bind(s,46611)),"/Users/yehiatarek/Documents/projects/Stacks/Stacks Stablecoin Engine (SSE)/frontend/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,9291,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,73881))).default(e),async e=>(await Promise.resolve().then(s.bind(s,97026))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],d=["/Users/yehiatarek/Documents/projects/Stacks/Stacks Stablecoin Engine (SSE)/frontend/src/app/my-stablecoins/page.tsx"],m="/my-stablecoins/page",u={require:s,loadChunk:()=>Promise.resolve()},x=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/my-stablecoins/page",pathname:"/my-stablecoins",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},9395:(e,t,s)=>{Promise.resolve().then(s.bind(s,57400))},57400:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>MyStablecoinsPage});var a=s(30784),r=s(9885),n=s(11440),l=s.n(n),i=s(23109),o=s(91672),c=s(71817),d=s(3817),m=s(5705),u=s(67276),x=s(65688),p=s(94163),h=s(71163),f=s(20644),b=s(22385),g=s(45304),j=s(97040),y=s(17133),N=s(86847),v=s(96170),S=s(15485),E=s(80467),w=s(71113);function protocolSlug(e){return e.name.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").replace(/-{2,}/g,"-")}function fmt(e,t=2){return null!=e&&Number.isFinite(e)?e.toLocaleString("en-US",{minimumFractionDigits:t,maximumFractionDigits:t}):"—"}function formatUsd(e,t=2){return null!==e&&Number.isFinite(e)?`$${(0,E.uf)(e,t)}`:"—"}function StablecoinCard({coin:e,priceByAsset:t}){let{decimals:s}=(0,S.ai)(e.tokenContract),{totalSupply:r}=(0,S.y9)(e.tokenContract),{holders:n}=(0,S.iU)(e.tokenContract),{metrics:h,isLoading:f}=(0,S.lD)(e.id,t),b=s??6,v=null!==r?(0,E.dJ)(r,b):null,C=h&&b>0?(0,E.dJ)(h.totalDebt,b):null,L=h?.totalRequiredCollateralUsd??null;return(0,a.jsxs)(j.Zb,{children:[a.jsx(j.Ol,{children:(0,a.jsxs)("div",{className:"flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"flex h-10 w-10 items-center justify-center rounded-full bg-primary/10",children:a.jsx("span",{className:"text-sm font-bold text-primary",children:e.symbol.charAt(0)})}),(0,a.jsxs)("div",{children:[(0,a.jsxs)(j.ll,{className:"flex items-center gap-2",children:[e.name,a.jsx("span",{className:"font-mono text-sm text-muted-foreground",children:e.symbol})]}),(0,a.jsxs)(j.SZ,{children:["ID #",e.id," \xb7 Registered at block ",e.registeredAt]})]})]}),a.jsx("div",{className:"flex flex-wrap gap-2",children:e.tokenContract?a.jsx(y.C,{variant:"success",children:"Token linked"}):a.jsx(y.C,{variant:"warning",children:"Token not deployed"})})]})}),(0,a.jsxs)(j.aY,{className:"space-y-6",children:[(0,a.jsxs)("div",{className:"grid gap-4 sm:grid-cols-2 lg:grid-cols-4",children:[(0,a.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between",children:[a.jsx("p",{className:"text-xs font-medium text-muted-foreground",children:"Total Supply"}),a.jsx(i.Z,{className:"h-4 w-4 text-muted-foreground"})]}),a.jsx("p",{className:"mt-2 text-xl font-bold",children:null!==v?(0,E.uf)(v,2):"—"}),(0,a.jsxs)("p",{className:"text-xs text-muted-foreground",children:[e.symbol," minted"]})]}),(0,a.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between",children:[a.jsx("p",{className:"text-xs font-medium text-muted-foreground",children:"Holders"}),a.jsx(o.Z,{className:"h-4 w-4 text-muted-foreground"})]}),a.jsx("p",{className:"mt-2 text-xl font-bold",children:n?(0,E.uf)(n.total,0):"—"}),a.jsx("p",{className:"text-xs text-muted-foreground",children:n&&n.total>0?"Unique addresses":"Awaiting indexing"})]}),(0,a.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between",children:[a.jsx("p",{className:"text-xs font-medium text-muted-foreground",children:"Outstanding Debt"}),a.jsx(c.Z,{className:"h-4 w-4 text-muted-foreground"})]}),a.jsx("p",{className:"mt-2 text-xl font-bold",children:null!==C?(0,E.uf)(C,2):"—"}),(0,a.jsxs)("p",{className:"text-xs text-muted-foreground",children:[e.symbol," debt across loans"]})]}),(0,a.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between",children:[a.jsx("p",{className:"text-xs font-medium text-muted-foreground",children:"Required Collateral"}),a.jsx(d.Z,{className:"h-4 w-4 text-muted-foreground"})]}),a.jsx("p",{className:"mt-2 text-xl font-bold",children:null!==L?formatUsd((0,E.dJ)(L,b),0):"—"}),a.jsx("p",{className:"text-xs text-muted-foreground",children:"Floor at min-ratio"})]})]}),(0,a.jsxs)("div",{children:[a.jsx("div",{className:"mb-3 flex items-center justify-between",children:(0,a.jsxs)("div",{children:[a.jsx("p",{className:"text-sm font-semibold",children:"Loan exposure by collateral"}),a.jsx("p",{className:"text-xs text-muted-foreground",children:"Aggregated debt and capacity per collateral asset. Per-borrower enumeration is not available on-chain."})]})}),f&&!h?(0,a.jsxs)("div",{className:"flex items-center gap-2 rounded-md border p-4 text-sm text-muted-foreground",children:[a.jsx(m.Z,{className:"h-4 w-4 animate-spin"}),"Loading collateral exposure…"]}):h&&0!==h.perAsset.length?a.jsx("div",{className:"overflow-hidden rounded-md border",children:(0,a.jsxs)("table",{className:"w-full text-sm",children:[a.jsx("thead",{className:"bg-muted/50 text-left text-xs text-muted-foreground",children:(0,a.jsxs)("tr",{children:[a.jsx("th",{className:"px-3 py-2 font-medium",children:"Asset"}),a.jsx("th",{className:"px-3 py-2 font-medium",children:"Status"}),a.jsx("th",{className:"px-3 py-2 font-medium",children:"Oracle"}),a.jsx("th",{className:"px-3 py-2 font-medium",children:"Min ratio"}),a.jsx("th",{className:"px-3 py-2 font-medium",children:"Debt"}),a.jsx("th",{className:"px-3 py-2 font-medium",children:"Utilization"})]})}),a.jsx("tbody",{children:h.perAsset.map(e=>{let t=b>0?(0,E.dJ)(e.debtOutstanding,b):e.debtOutstanding,s=b>0?(0,E.dJ)(e.debtCeiling,b):e.debtCeiling,r=Math.max(0,Math.min(e.utilization,100));return(0,a.jsxs)("tr",{className:"border-t",children:[(0,a.jsxs)("td",{className:"px-3 py-2 font-medium",children:[(0,w.Jh)(e.asset),a.jsx("p",{className:"font-mono text-xs text-muted-foreground",children:(0,E.Tg)(e.asset.split(".")[0]??"",4)})]}),a.jsx("td",{className:"px-3 py-2",children:e.enabled?a.jsx(y.C,{variant:"success",children:"Enabled"}):a.jsx(y.C,{variant:"secondary",children:"Disabled"})}),a.jsx("td",{className:"px-3 py-2",children:null!==e.oraclePrice?formatUsd(e.oraclePrice,2):"—"}),(0,a.jsxs)("td",{className:"px-3 py-2",children:[e.minCollateralRatio,"%"]}),(0,a.jsxs)("td",{className:"px-3 py-2",children:[(0,E.uf)(t,2)," / ",(0,E.uf)(s,0)]}),a.jsx("td",{className:"px-3 py-2",children:(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[a.jsx(N.E,{value:r,className:"h-2 w-24"}),(0,a.jsxs)("span",{className:"text-xs text-muted-foreground",children:[e.utilization.toFixed(1),"%"]})]})})]},e.asset)})})]})}):(0,a.jsxs)("div",{className:"rounded-md border border-dashed p-4 text-sm text-muted-foreground",children:["No collaterals configured for this stablecoin yet."," ",a.jsx(l(),{href:"/factory",className:"text-primary underline-offset-4 hover:underline",children:"Configure collaterals"}),"."]})]}),n&&n.topHolders.length>0&&(0,a.jsxs)("div",{children:[a.jsx("p",{className:"mb-2 text-sm font-semibold",children:"Top holders"}),a.jsx("div",{className:"flex flex-wrap gap-2",children:n.topHolders.map(e=>{let t=b>0?(0,E.dJ)(Number(e.balance),b):Number(e.balance);return(0,a.jsxs)(y.C,{variant:"secondary",className:"font-mono",children:[(0,E.Tg)(e.address,4)," \xb7 ",(0,E.uf)(t,2)]},e.address)})})]}),a.jsx("div",{className:"rounded-md border bg-muted/30 p-4",children:(0,a.jsxs)("div",{className:"flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",children:[(0,a.jsxs)("div",{children:[a.jsx("p",{className:"text-sm font-semibold",children:"List on DefiLlama"}),a.jsx("p",{className:"text-xs text-muted-foreground",children:"Downloads a markdown PR package with contract metadata, a live metrics snapshot, and a ready-to-paste TVL adapter. You open the PR yourself — no GitHub access needed from us."})]}),(0,a.jsxs)("div",{className:"flex flex-wrap gap-2",children:[(0,a.jsxs)(g.z,{size:"sm",onClick:()=>{let t=function(e){let{coin:t,metrics:s,tokenDecimals:a,totalSupply:r,holdersCount:n,origin:l}=e,i=protocolSlug(t),o=w.M8?"mainnet":"testnet",c=a??6,d=null!==r?r/10**c:null,m=s&&c>0?s.totalDebt/10**c:null,u=s?.totalRequiredCollateralUsd!==null&&s?.totalRequiredCollateralUsd!==void 0?s.totalRequiredCollateralUsd/10**c:null,x=function(e){let{coin:t}=e,s=w.M8?"mainnet":"testnet",a=w.M8?"https://api.mainnet.hiro.so":"https://api.testnet.hiro.so",r=t.tokenContract??"<deploy-token-contract-first>";return`// SPDX-License-Identifier: MIT
// DefiLlama TVL adapter for "${t.name}" (${t.symbol})
// Stablecoin issued on Stacks via the Stacks Stablecoin Engine (SSE).
// Submission target: https://github.com/DefiLlama/DefiLlama-Adapters

const { cvToHex, uintCV, principalCV, hexToCV, cvToValue } = require("@stacks/transactions");

const API_BASE = "${a}";
const DEPLOYER = "${w.qE.DEPLOYER}";
const FACTORY = "${w.qE.STABLECOIN_FACTORY}";
const COLLATERAL_REGISTRY = "${w.qE.COLLATERAL_REGISTRY}";
const STABLECOIN_ID = ${t.id};
const STABLECOIN_TOKEN = "${r}";
const NETWORK = "${s}";

async function callRead(contract, fn, args = []) {
  const [addr, name] = contract.includes(".") ? contract.split(".") : [DEPLOYER, contract];
  const resp = await fetch(\`\${API_BASE}/v2/contracts/call-read/\${addr}/\${name}/\${fn}\`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sender: DEPLOYER, arguments: args }),
  });
  if (!resp.ok) throw new Error(\`Hiro read failed: \${fn} (\${resp.status})\`);
  const data = await resp.json();
  if (!data.okay) throw new Error(\`Contract read failed: \${fn} - \${data.cause}\`);
  return cvToValue(hexToCV(data.result));
}

function toNumber(v) {
  if (v === null || v === undefined) return 0;
  if (typeof v === "bigint") return Number(v);
  if (typeof v === "number") return v;
  if (typeof v === "object" && "value" in v) return toNumber(v.value);
  if (typeof v === "string" && /^\\d+$/.test(v)) return Number(v);
  return 0;
}

async function collateralCount() {
  return toNumber(await callRead(COLLATERAL_REGISTRY, "get-stablecoin-collateral-count-ro", [
    cvToHex(uintCV(STABLECOIN_ID)),
  ]));
}

async function collateralAtIndex(i) {
  const res = await callRead(COLLATERAL_REGISTRY, "get-stablecoin-collateral-at-index", [
    cvToHex(uintCV(STABLECOIN_ID)),
    cvToHex(uintCV(i)),
  ]);
  return res && res.asset ? (res.asset.value || res.asset) : null;
}

async function debtForAsset(asset) {
  return toNumber(await callRead(COLLATERAL_REGISTRY, "get-stablecoin-collateral-debt-ro", [
    cvToHex(uintCV(STABLECOIN_ID)),
    cvToHex(principalCV(asset)),
  ]));
}

async function collateralConfig(asset) {
  return callRead(COLLATERAL_REGISTRY, "get-stablecoin-collateral-config", [
    cvToHex(uintCV(STABLECOIN_ID)),
    cvToHex(principalCV(asset)),
  ]);
}

async function tvl(api) {
  const n = await collateralCount();
  let totalUsd = 0;

  for (let i = 0; i < n; i++) {
    const asset = await collateralAtIndex(i);
    if (!asset) continue;

    const [debt, cfg] = await Promise.all([debtForAsset(asset), collateralConfig(asset)]);
    const minRatio = toNumber(cfg && cfg["min-collateral-ratio"]);

    // Debt is denominated in the stablecoin (~$1 per token unit). The required
    // collateral floor backing this debt is debt * minRatio / 100. SSE tokens
    // use 6 decimals, so we scale down before adding to the USD total.
    if (minRatio > 0) {
      totalUsd += (debt * minRatio) / 100 / 1e6;
    }
  }

  api.addUSDValue(totalUsd);
}

module.exports = {
  methodology:
    "TVL is the required-collateral floor backing the ${t.symbol} stablecoin, " +
    "computed per configured collateral as outstanding-debt x min-collateral-ratio. " +
    "Data is read directly from the Stacks Stablecoin Engine contracts via the Hiro API.",
  stacks: {
    tvl,
  },
};
`}(e),p=s&&s.perAsset.length>0?s.perAsset.map(e=>{let t=e.debtOutstanding/10**c,s=e.debtCeiling/10**c;return`| \`${e.asset}\` | ${e.minCollateralRatio}% | ${e.liquidationRatio}% | ${fmt(t)} | ${fmt(s,0)} | ${null!==e.oraclePrice?"$"+fmt(e.oraclePrice):"—"} | ${e.enabled?"yes":"no"} |`}).join("\n"):"| — | — | — | — | — | — | — |",h=`${w.qE.DEPLOYER}.${w.qE.STABLECOIN_FACTORY}`,f=`${w.qE.DEPLOYER}.${w.qE.MULTI_ASSET_VAULT_ENGINE}`,b=`${w.qE.DEPLOYER}.${w.qE.COLLATERAL_REGISTRY}`,g=`${w.qE.DEPLOYER}.${w.qE.LIQUIDATION_ENGINE}`,j=`${w.qE.DEPLOYER}.${w.qE.STABILITY_POOL}`;return`# DefiLlama listing: ${t.name} (${t.symbol})

> Submission package for the DefiLlama **Adapters** repository.
> Fork target: https://github.com/DefiLlama/DefiLlama-Adapters
>
> Generated by the Stacks Stablecoin Engine ${l?`at ${l}`:""} — no
> GitHub permissions were granted, everything below is for you to submit yourself.

---

## 1. Protocol summary

- **Name:** ${t.name}
- **Symbol:** ${t.symbol}
- **Chain:** Stacks (${o})
- **Category:** CDP / collateralised stablecoin
- **Website:** <fill-in-your-site>
- **Twitter:** <fill-in-your-handle>
- **Logo:** upload a 256x256 PNG alongside this PR (see repo instructions)
- **Audits:** <link or "none" if unaudited>

This stablecoin is issued on Stacks through the **Stacks Stablecoin Engine (SSE)**:
an open CDP protocol where issuers register a stablecoin, configure collateral
types with per-stablecoin parameters, and users mint against deposited collateral.

## 2. On-chain identifiers

| Role | Contract |
|------|----------|
| Stablecoin token (SIP-010) | \`${t.tokenContract??"token not deployed yet — deploy before submitting"}\` |
| Factory | \`${h}\` |
| Vault engine | \`${f}\` |
| Collateral registry | \`${b}\` |
| Liquidation engine | \`${g}\` |
| Stability pool | \`${j}\` |
| Stablecoin factory ID | \`${t.id}\` |
| Creator | \`${t.creator}\` |
| Registered at block | ${t.registeredAt} |

## 3. Live metrics snapshot

Captured ${new Date().toISOString()} via the Hiro API.

| Metric | Value |
|--------|-------|
| Total supply | ${null!==d?`${fmt(d)} ${t.symbol}`:"—"} |
| Holders | ${null!==n?fmt(n,0):"— (Hiro may still be indexing)"} |
| Outstanding debt | ${null!==m?`${fmt(m)} ${t.symbol}`:"—"} |
| Required collateral floor | ${null!==u?`$${fmt(u)}`:"—"} |

### Per-collateral breakdown

| Asset | Min ratio | Liquidation ratio | Debt | Debt ceiling | Oracle price | Enabled |
|-------|-----------|-------------------|------|--------------|--------------|---------|
${p}

## 4. TVL methodology

TVL is the **required-collateral floor** backing the stablecoin: for each
configured collateral, \`debt_outstanding * min_collateral_ratio / 100\`. Stacks
does not expose per-stablecoin deposited-collateral totals through a single
read-only call, so the required-collateral floor — which every healthy vault
must by definition exceed — is the conservative and auditable choice.

Source data is read directly from the SSE contracts via the Hiro API:
\`get-stablecoin-collateral-count-ro\`, \`get-stablecoin-collateral-at-index\`,
\`get-stablecoin-collateral-debt-ro\`, and \`get-stablecoin-collateral-config\`.

## 5. TVL adapter source

Save the following as \`projects/${i}/index.js\` in your fork of
\`DefiLlama/DefiLlama-Adapters\`:

\`\`\`javascript
${x}\`\`\`

## 6. How to submit (step-by-step, no access from us required)

1. **Fork** the DefiLlama Adapters repo — https://github.com/DefiLlama/DefiLlama-Adapters
2. **Clone your fork** locally:
   \`\`\`bash
   git clone https://github.com/<your-user>/DefiLlama-Adapters.git
   cd DefiLlama-Adapters
   git checkout -b add-${i}
   \`\`\`
3. **Create the adapter directory**:
   \`\`\`bash
   mkdir -p projects/${i}
   \`\`\`
4. **Add the adapter file** — paste the code from section 5 into
   \`projects/${i}/index.js\`.
5. **Test locally** per the repo's README (\`npm i && npx @defillama/sdk ...\`).
6. **Commit and push**:
   \`\`\`bash
   git add projects/${i}/index.js
   git commit -m "feat: add ${t.name} (${t.symbol}) stablecoin TVL adapter"
   git push origin add-${i}
   \`\`\`
7. **Open a pull request** against \`DefiLlama/DefiLlama-Adapters:main\`
   and paste sections 1–4 of this file as the PR description.
8. **Add a listing entry** by opening a separate issue or PR on
   https://github.com/DefiLlama/defillama-server
   if requested by reviewers (they will tell you which file to edit —
   commonly \`defi/src/protocols/data.ts\`).

## 7. Contact

- Creator address: \`${t.creator}\`
- Stablecoin Engine frontend: ${l||"<your SSE deployment URL>"}
- Questions about the adapter: open a comment on the PR and tag the creator.
`}({coin:e,metrics:h??null,tokenDecimals:s,totalSupply:r,holdersCount:n?.total??null,origin:""}),a=new Blob([t],{type:"text/markdown;charset=utf-8"}),l=URL.createObjectURL(a),i=document.createElement("a");i.href=l,i.download=`defillama-${protocolSlug(e)}-pr.md`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(l)},disabled:!e.tokenContract,title:e.tokenContract?void 0:"Deploy the token contract before generating the DefiLlama listing",children:[a.jsx(u.Z,{className:"mr-2 h-4 w-4"}),"Download PR package"]}),a.jsx(g.z,{variant:"outline",size:"sm",asChild:!0,children:(0,a.jsxs)("a",{href:"https://github.com/DefiLlama/DefiLlama-Adapters",target:"_blank",rel:"noopener noreferrer",children:[a.jsx(x.Z,{className:"mr-2 h-4 w-4"}),"Fork adapter repo"]})})]})]})}),(0,a.jsxs)("div",{className:"flex flex-wrap gap-2 border-t pt-4",children:[a.jsx(g.z,{variant:"outline",size:"sm",asChild:!0,children:(0,a.jsxs)(l(),{href:"/factory",children:[a.jsx(d.Z,{className:"mr-2 h-4 w-4"}),"Manage collaterals"]})}),a.jsx(g.z,{variant:"outline",size:"sm",asChild:!0,children:(0,a.jsxs)(l(),{href:"/liquidations",children:[a.jsx(p.Z,{className:"mr-2 h-4 w-4"}),"View liquidations"]})}),!e.tokenContract&&a.jsx(g.z,{variant:"outline",size:"sm",asChild:!0,children:(0,a.jsxs)(l(),{href:"/factory",children:[a.jsx(x.Z,{className:"mr-2 h-4 w-4"}),"Deploy token"]})})]})]})]})}function MyStablecoinsPage(){let{isConnected:e,address:t}=(0,v.R)(),[s,n]=(0,r.useState)(!1),{stablecoins:o,isLoading:c,refetch:d}=(0,S.dX)(t??null),{collateralTypes:u}=(0,S.Tz)(),x=(0,r.useMemo)(()=>{let e={};return u.forEach(t=>{e[t.asset]=t.oraclePrice}),e},[u]);return((0,r.useEffect)(()=>{n(!0)},[]),s)?e?(0,a.jsxs)("div",{className:"container px-4 py-8",children:[(0,a.jsxs)("div",{className:"mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",children:[(0,a.jsxs)("div",{children:[a.jsx("h1",{className:"text-3xl font-bold",children:"My Stablecoins"}),a.jsx("p",{className:"text-muted-foreground",children:"Supply, holders, and loan exposure for stablecoins you have issued."})]}),(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsxs)(g.z,{variant:"outline",size:"sm",onClick:d,disabled:c,children:[a.jsx(f.Z,{className:`mr-2 h-4 w-4 ${c?"animate-spin":""}`}),"Refresh"]}),a.jsx(g.z,{asChild:!0,children:(0,a.jsxs)(l(),{href:"/factory",children:[a.jsx(b.Z,{className:"mr-2 h-4 w-4"}),"Create Stablecoin"]})})]})]}),c&&0===o.length?a.jsx(j.Zb,{children:(0,a.jsxs)(j.aY,{className:"flex items-center justify-center py-12",children:[a.jsx(m.Z,{className:"mr-2 h-5 w-5 animate-spin text-muted-foreground"}),a.jsx("span",{className:"text-muted-foreground",children:"Loading your stablecoins…"})]})}):0===o.length?a.jsx(j.Zb,{children:(0,a.jsxs)(j.aY,{className:"flex flex-col items-center justify-center py-12 text-center",children:[a.jsx(i.Z,{className:"h-12 w-12 text-muted-foreground"}),a.jsx("p",{className:"mt-4 font-medium",children:"No stablecoins yet"}),a.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:"You haven't created any stablecoins with this address."}),a.jsx(g.z,{className:"mt-4",asChild:!0,children:(0,a.jsxs)(l(),{href:"/factory",children:[a.jsx(b.Z,{className:"mr-2 h-4 w-4"}),"Create Your First Stablecoin"]})})]})}):a.jsx("div",{className:"space-y-6",children:o.map(e=>a.jsx(StablecoinCard,{coin:e,priceByAsset:x},e.id))})]}):a.jsx("div",{className:"container flex flex-col items-center justify-center px-4 py-24",children:a.jsx(j.Zb,{className:"w-full max-w-md",children:(0,a.jsxs)(j.Ol,{className:"text-center",children:[a.jsx(h.Z,{className:"mx-auto h-12 w-12 text-muted-foreground"}),a.jsx(j.ll,{className:"mt-4",children:"Institution Login"}),a.jsx(j.SZ,{children:"Log in with your institution to view the stablecoins you have created."})]})})}):null}},86847:(e,t,s)=>{"use strict";s.d(t,{E:()=>i});var a=s(30784),r=s(9885),n=s(54328),l=s(80467);let i=r.forwardRef(({className:e,value:t,indicatorClassName:s,...r},i)=>a.jsx(n.fC,{ref:i,className:(0,l.cn)("relative h-4 w-full overflow-hidden rounded-full bg-secondary",e),...r,children:a.jsx(n.z$,{className:(0,l.cn)("h-full w-full flex-1 bg-primary transition-all",s),style:{transform:`translateX(-${100-(t||0)}%)`}})}));i.displayName=n.fC.displayName},48860:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>l,__esModule:()=>n,default:()=>o});var a=s(95153);let r=(0,a.createProxy)(String.raw`/Users/yehiatarek/Documents/projects/Stacks/Stacks Stablecoin Engine (SSE)/frontend/src/app/my-stablecoins/page.tsx`),{__esModule:n,$$typeof:l}=r,i=r.default,o=i}};var t=require("../../webpack-runtime.js");t.C(e);var __webpack_exec__=e=>t(t.s=e),s=t.X(0,[6126,3888,1323,925,4328,9987,1724,3317,1312,7040,6170,7133],()=>__webpack_exec__(89402));module.exports=s})();